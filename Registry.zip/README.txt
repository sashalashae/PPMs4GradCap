The files contained in this challenge have the potential to cause serious harm to your Windows host machine. They are not malicious in anyway, but are recognised by Windows as valid system files. Do not attempt to open these using the Windows Registry editor. All of the tools you need to solve all of the challenges are stored on the Virtual Machine you have been provided. 

The password for this evidence is:

do-not-import-into-host-registry